Place your profile image here as 'profile.jpg'
Recommended size: 400x400px or larger
Format: JPG, PNG, or WebP
The image should be square and high quality for best results.